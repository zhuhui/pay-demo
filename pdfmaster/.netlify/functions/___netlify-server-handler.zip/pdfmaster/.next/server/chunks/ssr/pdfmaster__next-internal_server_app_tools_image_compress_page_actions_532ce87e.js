module.exports=[95580,(a,b,c)=>{}];

//# sourceMappingURL=pdfmaster__next-internal_server_app_tools_image_compress_page_actions_532ce87e.js.map