globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/759adfaaba1f7dd9.js",
    "static/chunks/7b4e1b3ffb2fbc18.js",
    "static/chunks/5c8bcfe4de3e40a7.js",
    "static/chunks/09c4e7c334924f46.js",
    "static/chunks/turbopack-a4f4ae96e198e1d7.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];